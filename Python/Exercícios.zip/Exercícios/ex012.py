x = int(input("Insira o valor de x: "))

fx = float((4*(x**2)-(3*x)+9)/x)

print(fx)